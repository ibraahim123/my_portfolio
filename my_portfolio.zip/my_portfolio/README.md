# KoofiTech Starter Portfolio

A beginner-friendly responsive portfolio website made with **HTML, CSS and vanilla JavaScript**. No framework or build tools are required.

## Run the project

1. Extract the ZIP file.
2. Open the `koofitech-github-starter` folder in VS Code.
3. Open `index.html` in your browser, or use the VS Code Live Server extension.
4. Edit the text in `index.html` and the design in `style.css`.

## Project files

- `index.html` — website content and page structure
- `style.css` — colors, layout, responsive design and dark theme styles
- `script.js` — theme switch, mobile menu and automatic footer year
- `.gitignore` — files Git should ignore

## Publish to GitHub using Ubuntu Terminal

Open Terminal inside this folder, then run:

```bash
git init
git add .
git commit -m "Create KoofiTech starter portfolio"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the GitHub URL with the URL of the empty repository you create at https://github.com/new.

If `git remote add origin` says that `origin` already exists, use:

```bash
git remote set-url origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
```

## Update GitHub after editing

```bash
git add .
git commit -m "Update portfolio"
git push
```

## Before publishing

- Replace the sample email `hello@koofitech.com` with your real contact address.
- Update the About and Projects sections with your own information.
- Do not add passwords, API keys or private `.env` files.
