// KoofiTech starter project: small interactions using plain JavaScript.

const themeToggle = document.querySelector("#themeToggle");
const menuToggle = document.querySelector("#menuToggle");
const navLinks = document.querySelector("#navLinks");
const year = document.querySelector("#year");

// Show the current year automatically.
year.textContent = new Date().getFullYear();

// Switch between light and dark themes.
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const darkModeIsOn = document.body.classList.contains("dark");
  themeToggle.textContent = darkModeIsOn ? "☀" : "☾";
  themeToggle.setAttribute("aria-label", darkModeIsOn ? "Switch to light theme" : "Switch to dark theme");
});

// Open and close the mobile navigation.
menuToggle.addEventListener("click", () => {
  const menuIsOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(menuIsOpen));
  menuToggle.textContent = menuIsOpen ? "✕" : "☰";
});

// Close the mobile menu after selecting a link.
navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});
